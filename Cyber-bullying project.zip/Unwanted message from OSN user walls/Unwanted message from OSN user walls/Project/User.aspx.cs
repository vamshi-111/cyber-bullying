﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select UserName,Photo from RegistrationDetails where UserName='" + txtname.Text + "' and Password='" + txtpwd.Text + "' and Status !='blocked'";
        cmd.Connection = con;
        SqlDataReader sdr;
        sdr = cmd.ExecuteReader();
        if (sdr.Read())
        {
            Session["uname"] = sdr[0].ToString();
            Session["img"] = sdr[1].ToString();
            Response.Redirect("User/StatusUpdate.aspx");
        }
        else {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('You have enterd worng id (or) password!(or)your account is blocked')</script>");
          
        }
    }
}